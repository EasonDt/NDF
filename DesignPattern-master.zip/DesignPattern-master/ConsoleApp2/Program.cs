﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            var Number = 1488%8;
            var index = DateTime.MaxValue.Date;
            Console.WriteLine(index);
        }
    }
}
